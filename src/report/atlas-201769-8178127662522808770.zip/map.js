{
	"template":"Single Map (HTML Edition)",
	"version":"6.9.0_b1,968 (2017-06-09 0835)",
	"boundingBox":"-10496603.693999998 3341414.765 -9881916.566000002 3924918.455",
	"layers":[
	{
		"type":"base-layer",
		"id":"_louisiana_parishes.shp1",
		"name":"louisiana_parishes.shp",
		"geometry":"polygon",
		"url":"_louisiana_parishes.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	}
	]
}